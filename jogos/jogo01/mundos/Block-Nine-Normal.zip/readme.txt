==-=--=----=--------=----------------=----------------=--------=----=--=-==
You've just downloaded a       T Y P E A R O U N D   F O N T !         Yay!
==-=--=----=--------=----------------=----------------=--------=----=--=-==

Thank you for downloading a Typearound font. Please be aware that the fonts
on Typearound are original designs by Stephen Deken and Isabelle Trolio and
are free for non-commercial use. Actually, they're also free for commerical
use, too, we'd just like to know about it.

If you want to use these fonts commercially, please send mail to one of the
following addresses:

   stephen@typearound.com    (to contact Stephen Deken)
   isabelle@typearound.com   (to contact Isabelle Trolio)

Yeah, we know, you could have figured that out by yourself. I know, I know.
I'm sorry. Now that that's out of the way, though.. all fonts on Typearound
are copyrighted (c)1999 by Stephen Deken and Isabelle Trolio.

All rights, including the right to curse loudly in public, reserved.

Come to Typearound and download more fonts at http://www.typearound.com/ !
Visit Isabelle's home on the web at http://www.hellostranger.com/ !
Visit Stephen's home on the web at http://www.awdang.com/ !

Have a good day !